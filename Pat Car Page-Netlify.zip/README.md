# Pat Car Page

A professional, car-themed beginner JavaScript tutorial website created for a programming activity.

## Files
- `index.html` — page structure and content
- `style.css` — complete responsive styling
- `script.js` — interactive JavaScript features

## Features
- Professional car-themed landing page
- JavaScript beginner tutorial
- Variables, conditions, functions, and arrays examples
- Interactive Car Price Calculator
- Interactive Engine Status demo
- Embedded online JavaScript compiler
- Responsive mobile navigation
- Netlify-ready static website

## Deployment
This is a static website. No build command is required.

Netlify:
- Build command: leave blank
- Publish directory: `/` (root)

You can deploy the project through GitHub or by dragging the project folder into Netlify's manual deploy area.
