// Pat Car Page - JavaScript

// Mobile navigation
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
  });
});

// Car Price Calculator
const calculateBtn = document.getElementById("calculateBtn");
const carPrice = document.getElementById("carPrice");
const discount = document.getElementById("discount");
const priceResult = document.getElementById("priceResult");

function calculateFinalPrice(price, discountPercent) {
  const discountAmount = price * (discountPercent / 100);
  return price - discountAmount;
}

function formatPeso(amount) {
  return new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP",
    minimumFractionDigits: 2
  }).format(amount);
}

calculateBtn.addEventListener("click", () => {
  const price = Number(carPrice.value);
  const discountPercent = Number(discount.value);

  if (price < 0 || discountPercent < 0 || discountPercent > 100 || Number.isNaN(price) || Number.isNaN(discountPercent)) {
    priceResult.textContent = "Please enter valid values.";
    return;
  }

  const finalPrice = calculateFinalPrice(price, discountPercent);
  priceResult.textContent = `Final price: ${formatPeso(finalPrice)}`;
});

// Engine Status Demo
const engineBtn = document.getElementById("engineBtn");
const engineDisplay = document.getElementById("engineDisplay");
const engineStatus = document.getElementById("engineStatus");

let engineRunning = false;

function startEngine() {
  engineRunning = true;
  engineDisplay.classList.add("running");
  engineStatus.textContent = "Engine ON";
  engineBtn.textContent = "Stop Engine";
}

function stopEngine() {
  engineRunning = false;
  engineDisplay.classList.remove("running");
  engineStatus.textContent = "Engine OFF";
  engineBtn.textContent = "Start Engine";
}

engineBtn.addEventListener("click", () => {
  if (engineRunning) {
    stopEngine();
  } else {
    startEngine();
  }
});

// Footer year
document.getElementById("year").textContent = new Date().getFullYear();
